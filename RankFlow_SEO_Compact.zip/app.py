from flask import Flask, render_template, request, redirect, url_for, flash, abort, jsonify, g
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import sqlite3
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = 'sua_chave_secreta_aqui'

# Configuração do banco de dados
DATABASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'rankflow.db')

def get_db():
    if 'db' not in g:
        g.db = sqlite3.connect(DATABASE)
        g.db.row_factory = sqlite3.Row
    return g.db

@app.teardown_appcontext
def close_db(error):
    db = g.pop('db', None)
    if db is not None:
        db.close()

def init_db():
    db = get_db()
    c = db.cursor()
    
    # Criar tabelas
    c.execute('''
        CREATE TABLE IF NOT EXISTS usuario (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE NOT NULL,
            senha TEXT NOT NULL,
            nome TEXT
        )
    ''')
    
    c.execute('''
        CREATE TABLE IF NOT EXISTS cliente (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            website TEXT,
            descricao TEXT,
            data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            usuario_id INTEGER NOT NULL,
            FOREIGN KEY (usuario_id) REFERENCES usuario (id)
        )
    ''')
    
    c.execute('''
        CREATE TABLE IF NOT EXISTS membro_equipe (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            cliente_id INTEGER NOT NULL,
            nome TEXT NOT NULL,
            cargo TEXT,
            email TEXT,
            data_adicao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            ativo INTEGER DEFAULT 1,
            FOREIGN KEY (cliente_id) REFERENCES cliente (id)
        )
    ''')

    c.execute('''
        CREATE TABLE IF NOT EXISTS tarefa (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            cliente_id INTEGER NOT NULL,
            titulo TEXT NOT NULL,
            descricao TEXT,
            status TEXT NOT NULL DEFAULT 'todo',
            prioridade TEXT NOT NULL DEFAULT 'medium',
            checklist TEXT,
            data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            data_atualizacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (cliente_id) REFERENCES cliente (id)
        )
    ''')

    db.commit()

# Inicializar o banco de dados
with app.app_context():
    init_db()

# Configuração do Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

class Usuario(UserMixin):
    def __init__(self, id, email, nome):
        self.id = id
        self.email = email
        self.nome = nome

    def get_id(self):
        return str(self.id)

    @staticmethod
    def get(user_id):
        try:
            db = get_db()
            user = db.execute('SELECT * FROM usuario WHERE id = ?', (user_id,)).fetchone()
            if user is None:
                return None
            return Usuario(user['id'], user['email'], user['nome'])
        except Exception as e:
            print(f"Erro ao carregar usuário: {e}")
            return None

@login_manager.user_loader
def load_user(user_id):
    return Usuario.get(int(user_id))

@app.context_processor
def inject_clients():
    try:
        if current_user.is_authenticated:
            db = get_db()
            cursor = db.cursor()
            cursor.execute('SELECT id, nome FROM cliente WHERE usuario_id = ? ORDER BY nome', (current_user.id,))
            clientes = [dict(id=row[0], nome=row[1]) for row in cursor.fetchall()]
            return {'clientes': clientes}
    except Exception as e:
        print(f"Erro ao carregar clientes: {e}")
    return {'clientes': []}

@app.route('/')
def index():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    return render_template('login.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        senha = request.form.get('senha')
        
        db = get_db()
        user = db.execute('SELECT * FROM usuario WHERE email = ?', (email,)).fetchone()
        
        if user and check_password_hash(user['senha'], senha):
            usuario = Usuario(user['id'], user['email'], user['nome'])
            login_user(usuario)
            flash('Login realizado com sucesso!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Email ou senha incorretos.', 'error')
    
    return render_template('login.html')

@app.route('/cadastro', methods=['GET', 'POST'])
def cadastro():
    if request.method == 'POST':
        email = request.form.get('email')
        senha = request.form.get('senha')
        nome = request.form.get('nome')
        
        db = get_db()
        if db.execute('SELECT id FROM usuario WHERE email = ?', (email,)).fetchone():
            flash('Email já cadastrado.', 'error')
            return redirect(url_for('cadastro'))
        
        hash_senha = generate_password_hash(senha)
        db.execute('INSERT INTO usuario (email, senha, nome) VALUES (?, ?, ?)',
                  (email, hash_senha, nome))
        db.commit()
        
        flash('Cadastro realizado com sucesso!', 'success')
        return redirect(url_for('login'))
    
    return render_template('cadastro.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Logout realizado com sucesso!', 'success')
    return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    db = get_db()
    clientes = db.execute('''
        SELECT 
            c.id,
            c.nome,
            c.website,
            c.descricao,
            c.data_criacao,
            COUNT(DISTINCT k.id) as total_keywords,
            COUNT(DISTINCT t.id) as total_tarefas,
            COUNT(DISTINCT CASE WHEN t.status = 'concluida' THEN t.id END) as tarefas_concluidas
        FROM cliente c
        LEFT JOIN keyword k ON k.cliente_id = c.id
        LEFT JOIN tarefa t ON t.cliente_id = c.id
        WHERE c.usuario_id = ?
        GROUP BY c.id, c.nome, c.website, c.descricao, c.data_criacao
        ORDER BY c.data_criacao DESC
    ''', (current_user.id,)).fetchall()
    
    return render_template('dashboard.html', 
                         clientes=clientes,
                         total_clientes=len(clientes))

@app.route('/clientes/novo', methods=['GET', 'POST'])
@login_required
def novo_cliente():
    if request.method == 'POST':
        nome = request.form.get('nome')
        website = request.form.get('website')
        descricao = request.form.get('descricao')
        
        if not nome:
            flash('O nome do cliente é obrigatório.', 'error')
            return redirect(url_for('novo_cliente'))
        
        try:
            db = get_db()
            cursor = db.execute('''
                INSERT INTO cliente (nome, website, descricao, usuario_id, data_criacao)
                VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
            ''', (nome, website, descricao, current_user.id))
            db.commit()
            
            cliente_id = cursor.lastrowid
            flash('Cliente adicionado com sucesso!', 'success')
            return redirect(url_for('dashboard'))
            
        except Exception as e:
            db.rollback()
            flash('Erro ao adicionar cliente. Por favor, tente novamente.', 'error')
            return redirect(url_for('novo_cliente'))
    
    return render_template('novo_cliente.html')

@app.route('/cliente/<int:cliente_id>')
@login_required
def cliente_detalhes(cliente_id):
    db = get_db()
    cliente = db.execute('''
        SELECT c.*, 
               COUNT(DISTINCT k.id) as total_keywords,
               COUNT(DISTINCT t.id) as total_tarefas,
               COUNT(DISTINCT CASE WHEN t.status = 'concluida' THEN t.id END) as tarefas_concluidas
        FROM cliente c
        LEFT JOIN keyword k ON k.cliente_id = c.id
        LEFT JOIN tarefa t ON t.cliente_id = c.id
        WHERE c.id = ? AND c.usuario_id = ?
        GROUP BY c.id
    ''', (cliente_id, current_user.id)).fetchone()
    
    if not cliente:
        abort(404)
    
    # Converter cliente para dicionário e formatar datas
    cliente_dict = dict(cliente)
    try:
        data_str = cliente_dict['data_criacao']
        if data_str:
            data_criacao = datetime.strptime(data_str, '%Y-%m-%d %H:%M:%S')
            cliente_dict['data_criacao'] = data_criacao
    except (ValueError, TypeError):
        cliente_dict['data_criacao'] = datetime.now()
    
    membros = db.execute('''
        SELECT * FROM membro_equipe
        WHERE cliente_id = ? AND ativo = 1
        ORDER BY data_adicao DESC
    ''', (cliente_id,)).fetchall()
    
    # Converter membros e formatar datas
    membros_formatados = []
    for membro in membros:
        membro_dict = dict(membro)
        try:
            data_str = membro_dict['data_adicao']
            if data_str:
                data_adicao = datetime.strptime(data_str, '%Y-%m-%d %H:%M:%S')
                membro_dict['data_adicao'] = data_adicao
        except (ValueError, TypeError):
            membro_dict['data_adicao'] = datetime.now()
        membros_formatados.append(membro_dict)
    
    tarefas = db.execute('''
        SELECT t.*, m.nome as responsavel_nome
        FROM tarefa t
        LEFT JOIN membro_equipe m ON m.id = t.responsavel_id
        WHERE t.cliente_id = ?
        ORDER BY t.data_criacao DESC
    ''', (cliente_id,)).fetchall()
    
    # Converter tarefas e formatar datas
    tarefas_formatadas = []
    for tarefa in tarefas:
        tarefa_dict = dict(tarefa)
        try:
            data_str = tarefa_dict['data_criacao']
            if data_str:
                data_criacao = datetime.strptime(data_str, '%Y-%m-%d %H:%M:%S')
                tarefa_dict['data_criacao'] = data_criacao
        except (ValueError, TypeError):
            tarefa_dict['data_criacao'] = datetime.now()
        
        try:
            data_str = tarefa_dict['data_conclusao']
            if data_str:
                data_conclusao = datetime.strptime(data_str, '%Y-%m-%d %H:%M:%S')
                tarefa_dict['data_conclusao'] = data_conclusao
        except (ValueError, TypeError):
            tarefa_dict['data_conclusao'] = None
        tarefas_formatadas.append(tarefa_dict)
    
    return render_template('cliente_detalhes.html', 
                         cliente=cliente_dict,
                         membros=membros_formatados,
                         tarefas=tarefas_formatadas)

@app.route('/cliente/<int:cliente_id>/membros', methods=['POST'])
@login_required
def adicionar_membro(cliente_id):
    db = get_db()
    cliente = db.execute('SELECT * FROM cliente WHERE id = ? AND usuario_id = ?',
                        (cliente_id, current_user.id)).fetchone()
    if not cliente:
        abort(403)
    
    email = request.form.get('email')
    nome = request.form.get('nome')
    permissao = request.form.get('permissao', 'editor')
    
    membro = db.execute('''
        SELECT * FROM membro_equipe 
        WHERE email = ? AND cliente_id = ?
    ''', (email, cliente_id)).fetchone()
    
    if membro:
        if not membro['ativo']:
            db.execute('''
                UPDATE membro_equipe 
                SET ativo = 1 
                WHERE id = ?
            ''', (membro['id'],))
            db.commit()
            flash('Membro reativado com sucesso!', 'success')
        else:
            flash('Este email já está cadastrado na equipe.', 'warning')
        return redirect(url_for('cliente_detalhes', cliente_id=cliente_id))
    
    db.execute('''
        INSERT INTO membro_equipe (email, nome, permissao, cliente_id)
        VALUES (?, ?, ?, ?)
    ''', (email, nome, permissao, cliente_id))
    db.commit()
    
    flash('Membro adicionado com sucesso!', 'success')
    return redirect(url_for('cliente_detalhes', cliente_id=cliente_id))

@app.route('/cliente/<int:cliente_id>/membros/<int:membro_id>', methods=['PUT'])
@login_required
def atualizar_membro(cliente_id, membro_id):
    db = get_db()
    cliente = db.execute('SELECT * FROM cliente WHERE id = ? AND usuario_id = ?',
                        (cliente_id, current_user.id)).fetchone()
    if not cliente:
        abort(403)
    
    membro = db.execute('SELECT * FROM membro_equipe WHERE id = ? AND cliente_id = ?',
                       (membro_id, cliente_id)).fetchone()
    if not membro:
        abort(404)
    
    data = request.get_json()
    if 'permissao' in data:
        db.execute('UPDATE membro_equipe SET permissao = ? WHERE id = ?',
                  (data['permissao'], membro_id))
        db.commit()
    
    return jsonify({'message': 'Membro atualizado com sucesso'})

@app.route('/cliente/<int:cliente_id>/membros/<int:membro_id>', methods=['DELETE'])
@login_required
def remover_membro(cliente_id, membro_id):
    db = get_db()
    cliente = db.execute('SELECT * FROM cliente WHERE id = ? AND usuario_id = ?',
                        (cliente_id, current_user.id)).fetchone()
    if not cliente:
        abort(403)
    
    membro = db.execute('SELECT * FROM membro_equipe WHERE id = ? AND cliente_id = ?',
                       (membro_id, cliente_id)).fetchone()
    if not membro:
        abort(404)
    
    db.execute('UPDATE membro_equipe SET ativo = 0 WHERE id = ?', (membro_id,))
    db.commit()
    
    return jsonify({'message': 'Membro removido com sucesso'})

# Rotas do Kanban SEO Técnico
@app.route('/cliente/<int:cliente_id>/seo-tecnico')
@login_required
def seo_tecnico_kanban(cliente_id):
    try:
        db = get_db()
        cliente = db.execute('SELECT * FROM cliente WHERE id = ? AND usuario_id = ?', 
                            (cliente_id, current_user.id)).fetchone()
        
        if not cliente:
            abort(404)
        
        # Verificar se já existem tarefas para este cliente
        tarefas_existentes = db.execute('SELECT COUNT(*) as count FROM tarefa WHERE cliente_id = ?', 
                                      (cliente_id,)).fetchone()
        
        # Se não houver tarefas, criar as tarefas padrão
        if tarefas_existentes['count'] == 0:
            try:
                # Criar tarefas padrão
                tarefas_padrao = [
                    ('Análise de Velocidade do Site', 'Realizar análise completa da velocidade do site usando PageSpeed Insights', 'high', 
                     '[{"text": "Executar teste no PageSpeed Insights", "completed": false},{"text": "Otimizar imagens", "completed": false},{"text": "Minificar CSS/JS", "completed": false},{"text": "Configurar cache", "completed": false}]'),
                    ('Verificação Mobile-Friendly', 'Verificar se o site está totalmente adaptado para dispositivos móveis', 'high',
                     '[{"text": "Teste de responsividade", "completed": false},{"text": "Verificar viewport", "completed": false},{"text": "Testar formulários", "completed": false},{"text": "Checar fontes", "completed": false}]'),
                    ('Estrutura de URLs', 'Analisar e otimizar a estrutura de URLs do site', 'medium',
                     '[{"text": "Verificar URLs amigáveis", "completed": false},{"text": "Implementar breadcrumbs", "completed": false},{"text": "Verificar canonical tags", "completed": false},{"text": "Mapear redirecionamentos", "completed": false}]'),
                    ('Meta Tags', 'Otimizar meta tags de todas as páginas', 'high',
                     '[{"text": "Verificar title tags", "completed": false},{"text": "Otimizar meta descriptions", "completed": false},{"text": "Implementar Open Graph", "completed": false},{"text": "Verificar heading tags", "completed": false}]'),
                    ('Sitemap XML', 'Criar e otimizar o sitemap do site', 'medium',
                     '[{"text": "Gerar sitemap XML", "completed": false},{"text": "Validar estrutura", "completed": false},{"text": "Submeter ao Google", "completed": false},{"text": "Monitorar indexação", "completed": false}]'),
                    ('Robots.txt', 'Configurar e otimizar o arquivo robots.txt', 'medium',
                     '[{"text": "Criar/revisar robots.txt", "completed": false},{"text": "Definir diretrizes", "completed": false},{"text": "Testar configurações", "completed": false},{"text": "Verificar bloqueios", "completed": false}]'),
                    ('SSL/HTTPS', 'Verificar e otimizar a segurança do site', 'high',
                     '[{"text": "Verificar certificado SSL", "completed": false},{"text": "Configurar redirecionamentos", "completed": false},{"text": "Corrigir conteúdo misto", "completed": false},{"text": "Testar segurança", "completed": false}]'),
                    ('Links Quebrados', 'Identificar e corrigir links quebrados', 'medium',
                     '[{"text": "Fazer varredura completa", "completed": false},{"text": "Identificar 404s", "completed": false},{"text": "Corrigir redirecionamentos", "completed": false},{"text": "Verificar links externos", "completed": false}]'),
                    ('Schema Markup', 'Implementar marcações de dados estruturados', 'medium',
                     '[{"text": "Identificar tipos necessários", "completed": false},{"text": "Implementar markup", "completed": false},{"text": "Testar no validador", "completed": false},{"text": "Monitorar resultados", "completed": false}]'),
                    ('Canonical Tags', 'Implementar e otimizar canonical tags', 'medium',
                     '[{"text": "Identificar duplicações", "completed": false},{"text": "Implementar canonicals", "completed": false},{"text": "Verificar implementação", "completed": false},{"text": "Monitorar indexação", "completed": false}]')
                ]
                
                for titulo, descricao, prioridade, checklist in tarefas_padrao:
                    db.execute('''
                        INSERT INTO tarefa (cliente_id, titulo, descricao, prioridade, checklist, status)
                        VALUES (?, ?, ?, ?, ?, 'todo')
                    ''', (cliente_id, titulo, descricao, prioridade, checklist))
                db.commit()
            except Exception as e:
                print(f"Erro ao criar tarefas padrão: {str(e)}")
                db.rollback()
                raise
        
        # Carregar tarefas do banco de dados
        todo_tasks = db.execute('''
            SELECT * FROM tarefa 
            WHERE cliente_id = ? AND status = 'todo'
            ORDER BY prioridade DESC, data_criacao DESC
        ''', (cliente_id,)).fetchall()
        
        doing_tasks = db.execute('''
            SELECT * FROM tarefa 
            WHERE cliente_id = ? AND status = 'doing'
            ORDER BY prioridade DESC, data_criacao DESC
        ''', (cliente_id,)).fetchall()
        
        done_tasks = db.execute('''
            SELECT * FROM tarefa 
            WHERE cliente_id = ? AND status = 'done'
            ORDER BY prioridade DESC, data_criacao DESC
        ''', (cliente_id,)).fetchall()
        
        # Calcular progresso geral
        total_tasks = len(todo_tasks) + len(doing_tasks) + len(done_tasks)
        if total_tasks > 0:
            progress = round((len(done_tasks) / total_tasks * 100), 1)
        else:
            progress = 0
        
        # Converter os resultados em dicionários
        def row_to_dict(row):
            try:
                if row is None:
                    return None
                return {
                    'id': row['id'],
                    'title': row['titulo'],
                    'description': row['descricao'],
                    'priority': row['prioridade'],
                    'checklist': row['checklist'],
                    'date': row['data_criacao'],
                    'status': row['status'],
                    'priority_class': {
                        'high': 'priority-high',
                        'medium': 'priority-medium',
                        'low': 'priority-low'
                    }.get(row['prioridade'], 'priority-medium'),
                    'checklist_progress': calculate_checklist_progress(row['checklist'])
                }
            except Exception as e:
                print(f"Erro ao converter row para dict: {str(e)}")
                print(f"Row: {row}")
                raise
        
        todo_tasks = [row_to_dict(task) for task in todo_tasks]
        doing_tasks = [row_to_dict(task) for task in doing_tasks]
        done_tasks = [row_to_dict(task) for task in done_tasks]
        
        return render_template('seo_tecnico_kanban.html',
                             cliente=cliente,
                             todo_tasks=todo_tasks,
                             doing_tasks=doing_tasks,
                             done_tasks=done_tasks,
                             todo_count=len(todo_tasks),
                             doing_count=len(doing_tasks),
                             done_count=len(done_tasks),
                             progress=progress)
    except Exception as e:
        print(f"Erro na rota seo_tecnico_kanban: {str(e)}")
        db.rollback()
        abort(500)

def calculate_checklist_progress(checklist_json):
    if not checklist_json:
        return 0
    try:
        import json
        checklist = json.loads(checklist_json)
        if not checklist:
            return 0
        completed = sum(1 for item in checklist if item.get('completed', False))
        return round((completed / len(checklist) * 100), 1)
    except Exception as e:
        print(f"Erro ao calcular progresso do checklist: {str(e)}")
        print(f"Checklist JSON: {checklist_json}")
        return 0

@app.route('/api/task/update-status', methods=['POST'])
@login_required
def update_task_status():
    data = request.get_json()
    task_id = data.get('taskId')
    new_status = data.get('newStatus')
    
    if not task_id or not new_status:
        return jsonify({'error': 'Dados inválidos'}), 400
    
    db = get_db()
    try:
        db.execute('''
            UPDATE tarefa 
            SET status = ?, data_atualizacao = CURRENT_TIMESTAMP 
            WHERE id = ?
        ''', (new_status, task_id))
        db.commit()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/task/<int:task_id>', methods=['GET'])
@login_required
def get_task(task_id):
    db = get_db()
    task = db.execute('SELECT * FROM tarefa WHERE id = ?', (task_id,)).fetchone()
    
    if not task:
        return jsonify({'error': 'Tarefa não encontrada'}), 404
    
    return jsonify({
        'id': task['id'],
        'title': task['titulo'],
        'description': task['descricao'],
        'priority': task['prioridade'],
        'checklist': task['checklist'],
        'status': task['status'],
        'date': task['data_criacao']
    })

@app.route('/api/task/<int:task_id>', methods=['PUT'])
@login_required
def update_task(task_id):
    data = request.get_json()
    
    db = get_db()
    try:
        db.execute('''
            UPDATE tarefa 
            SET titulo = ?, 
                descricao = ?, 
                prioridade = ?,
                checklist = ?,
                data_atualizacao = CURRENT_TIMESTAMP 
            WHERE id = ?
        ''', (
            data['title'],
            data['description'],
            data['priority'],
            data['checklist'],
            task_id
        ))
        db.commit()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/tasks/filter', methods=['POST'])
@login_required
def filter_tasks():
    data = request.get_json()
    cliente_id = data.get('clienteId')
    priority = data.get('priority')
    date_range = data.get('dateRange')
    
    if not cliente_id:
        return jsonify({'error': 'ID do cliente é obrigatório'}), 400
    
    query = '''
        SELECT * FROM tarefa 
        WHERE cliente_id = ?
    '''
    params = [cliente_id]
    
    if priority:
        query += ' AND prioridade = ?'
        params.append(priority)
    
    if date_range:
        query += ' AND data_criacao >= ? AND data_criacao <= ?'
        params.extend([date_range['start'], date_range['end']])
    
    db = get_db()
    try:
        tasks = db.execute(query, params).fetchall()
        return jsonify([{
            'id': task['id'],
            'title': task['titulo'],
            'description': task['descricao'],
            'priority': task['prioridade'],
            'checklist': task['checklist'],
            'status': task['status'],
            'date': task['data_criacao']
        } for task in tasks])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/tasks/export/<int:cliente_id>', methods=['GET'])
@login_required
def export_tasks(cliente_id):
    db = get_db()
    tasks = db.execute('''
        SELECT * FROM tarefa 
        WHERE cliente_id = ? 
        ORDER BY status, prioridade DESC, data_criacao ASC
    ''', (cliente_id,)).fetchall()
    
    if not tasks:
        return jsonify({'error': 'Nenhuma tarefa encontrada'}), 404
    
    # Calcular estatísticas
    total_tasks = len(tasks)
    done_tasks = sum(1 for task in tasks if task['status'] == 'done')
    progress = round((done_tasks / total_tasks * 100), 1) if total_tasks > 0 else 0
    
    # Preparar dados para exportação
    export_data = {
        'date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'progress': progress,
        'total_tasks': total_tasks,
        'done_tasks': done_tasks,
        'tasks': [{
            'title': task['titulo'],
            'status': task['status'],
            'priority': task['prioridade'],
            'description': task['descricao'],
            'checklist': task['checklist'],
            'created_at': task['data_criacao'],
            'updated_at': task['data_atualizacao']
        } for task in tasks]
    }
    
    return jsonify(export_data)

@app.route('/cliente/<int:cliente_id>/tarefas', methods=['POST'])
@login_required
def criar_tarefa(cliente_id):
    try:
        db = get_db()
        data = request.get_json()
        
        if not data:
            return jsonify({'success': False, 'error': 'Dados não fornecidos'}), 400
            
        titulo = data.get('titulo')
        descricao = data.get('descricao', '')
        tipo = data.get('tipo')
        responsavel_id = data.get('responsavel_id')
        etapa_seo_id = data.get('etapa_seo_id')
        
        if not titulo:
            return jsonify({'success': False, 'error': 'Título é obrigatório'}), 400
        
        # Verificar se o cliente pertence ao usuário
        cliente = db.execute('''
            SELECT id FROM cliente 
            WHERE id = ? AND usuario_id = ?
        ''', (cliente_id, current_user.id)).fetchone()
        
        if not cliente:
            return jsonify({'success': False, 'error': 'Cliente não encontrado'}), 404
        
        # Se for uma tarefa de SEO técnico, adicionar o template
        if etapa_seo_id:
            try:
                etapa_seo_id = int(etapa_seo_id)
                if etapa_seo_id in TEMPLATES_TAREFAS_SEO:
                    template = TEMPLATES_TAREFAS_SEO[etapa_seo_id]
                    if descricao:
                        descricao = f"{descricao}\n\n{template}"
                    else:
                        descricao = template
            except (ValueError, TypeError):
                pass
        
        # Inserir a tarefa
        cursor = db.execute('''
            INSERT INTO tarefa (
                cliente_id, titulo, descricao, tipo, 
                responsavel_id, etapa_seo_id, status
            )
            VALUES (?, ?, ?, ?, ?, ?, 'pendente')
        ''', (cliente_id, titulo, descricao, tipo, responsavel_id, etapa_seo_id))
        
        db.commit()
        
        # Retornar a tarefa criada
        tarefa_id = cursor.lastrowid
        tarefa = db.execute('''
            SELECT 
                t.*,
                m.nome as responsavel
            FROM tarefa t
            LEFT JOIN membro_equipe m ON m.id = t.responsavel_id
            WHERE t.id = ?
        ''', (tarefa_id,)).fetchone()
        
        return jsonify({
            'success': True,
            'message': 'Tarefa criada com sucesso',
            'tarefa': dict(tarefa)
        })
        
    except Exception as e:
        db.rollback()
        return jsonify({
            'success': False,
            'error': f'Erro ao criar tarefa: {str(e)}'
        }), 500

@app.route('/cliente/<int:cliente_id>/tarefas/<int:tarefa_id>', methods=['PUT'])
@login_required
def atualizar_tarefa(cliente_id, tarefa_id):
    db = get_db()
    cliente = db.execute('SELECT * FROM cliente WHERE id = ? AND usuario_id = ?',
                        (cliente_id, current_user.id)).fetchone()
    if not cliente:
        abort(403)
    
    tarefa = db.execute('SELECT * FROM tarefa WHERE id = ? AND cliente_id = ?',
                       (tarefa_id, cliente_id)).fetchone()
    if not tarefa:
        abort(404)
    
    data = request.get_json()
    if 'status' in data:
        db.execute('''
            UPDATE tarefa 
            SET status = ?,
                data_conclusao = CASE WHEN ? = 'concluida' THEN CURRENT_TIMESTAMP ELSE NULL END
            WHERE id = ?
        ''', (data['status'], data['status'], tarefa_id))
        db.commit()
    
    return jsonify({'success': True, 'message': 'Tarefa atualizada com sucesso'})

@app.route('/cliente/<int:cliente_id>/tarefas/<int:tarefa_id>', methods=['DELETE'])
@login_required
def remover_tarefa(cliente_id, tarefa_id):
    db = get_db()
    cliente = db.execute('SELECT * FROM cliente WHERE id = ? AND usuario_id = ?',
                        (cliente_id, current_user.id)).fetchone()
    if not cliente:
        abort(403)
    
    tarefa = db.execute('SELECT * FROM tarefa WHERE id = ? AND cliente_id = ?',
                       (tarefa_id, cliente_id)).fetchone()
    if not tarefa:
        abort(404)
    
    db.execute('DELETE FROM tarefa WHERE id = ?', (tarefa_id,))
    db.commit()
    
    return jsonify({'success': True, 'message': 'Tarefa removida com sucesso'})

@app.route('/cliente/<int:cliente_id>/editar', methods=['GET', 'POST'])
@login_required
def editar_cliente(cliente_id):
    db = get_db()
    cliente = db.execute('''
        SELECT * FROM cliente 
        WHERE id = ? AND usuario_id = ?
    ''', (cliente_id, current_user.id)).fetchone()
    
    if not cliente:
        abort(404)
    
    if request.method == 'POST':
        nome = request.form.get('nome')
        website = request.form.get('website')
        descricao = request.form.get('descricao')
        
        if not nome:
            flash('O nome do cliente é obrigatório.', 'error')
            return redirect(url_for('editar_cliente', cliente_id=cliente_id))
        
        try:
            db.execute('''
                UPDATE cliente 
                SET nome = ?, website = ?, descricao = ?
                WHERE id = ? AND usuario_id = ?
            ''', (nome, website, descricao, cliente_id, current_user.id))
            db.commit()
            
            flash('Cliente atualizado com sucesso!', 'success')
            return redirect(url_for('dashboard'))
            
        except Exception as e:
            db.rollback()
            flash('Erro ao atualizar cliente. Por favor, tente novamente.', 'error')
    
    return render_template('editar_cliente.html', cliente=cliente)

@app.route('/cliente/<int:cliente_id>/excluir', methods=['POST'])
@login_required
def excluir_cliente(cliente_id):
    db = get_db()
    cliente = db.execute('''
        SELECT * FROM cliente 
        WHERE id = ? AND usuario_id = ?
    ''', (cliente_id, current_user.id)).fetchone()
    
    if not cliente:
        abort(404)
    
    try:
        # Primeiro excluir registros relacionados
        db.execute('DELETE FROM keyword WHERE cliente_id = ?', (cliente_id,))
        db.execute('DELETE FROM tarefa WHERE cliente_id = ?', (cliente_id,))
        db.execute('DELETE FROM membro_equipe WHERE cliente_id = ?', (cliente_id,))
        
        # Depois excluir o cliente
        db.execute('DELETE FROM cliente WHERE id = ? AND usuario_id = ?', 
                  (cliente_id, current_user.id))
        db.commit()
        
        flash('Cliente excluído com sucesso!', 'success')
        
    except Exception as e:
        db.rollback()
        flash('Erro ao excluir cliente. Por favor, tente novamente.', 'error')
    
    return redirect(url_for('dashboard'))

@app.route('/cliente/<int:cliente_id>/seo-roadmap')
@login_required
def seo_roadmap(cliente_id):
    db = get_db()
    cliente = db.execute('''
        SELECT * FROM cliente 
        WHERE id = ? AND usuario_id = ?
    ''', (cliente_id, current_user.id)).fetchone()
    
    if not cliente:
        abort(404)
    
    # Buscar todas as etapas e seu progresso
    etapas = db.execute('''
        SELECT 
            e.*,
            p.status,
            p.data_conclusao,
            p.observacoes,
            COUNT(t.id) as total_tarefas,
            SUM(CASE WHEN t.status = 'concluida' THEN 1 ELSE 0 END) as tarefas_concluidas
        FROM etapa_seo e
        LEFT JOIN progresso_seo p ON p.etapa_id = e.id AND p.cliente_id = ?
        LEFT JOIN tarefa t ON t.etapa_seo_id = e.id AND t.cliente_id = ?
        GROUP BY e.id
        ORDER BY e.ordem
    ''', (cliente_id, cliente_id)).fetchall()
    
    # Converter etapas para lista de dicionários
    etapas_dict = []
    for etapa in etapas:
        etapa_dict = dict(etapa)
        tarefas = db.execute('''
            SELECT 
                t.*,
                m.nome as responsavel
            FROM tarefa t
            LEFT JOIN membro_equipe m ON m.id = t.responsavel_id
            WHERE t.etapa_seo_id = ? AND t.cliente_id = ?
            ORDER BY t.data_criacao DESC
        ''', (etapa['id'], cliente_id)).fetchall()
        
        # Converter tarefas para lista de dicionários
        etapa_dict['tarefas'] = [dict(tarefa) for tarefa in tarefas]
        etapas_dict.append(etapa_dict)
    
    # Calcular progresso geral
    total_peso = sum(etapa['peso'] for etapa in etapas_dict)
    peso_concluido = sum(
        etapa['peso'] 
        for etapa in etapas_dict 
        if etapa['status'] == 'concluida'
    )
    
    progresso_geral = (peso_concluido / total_peso * 100) if total_peso > 0 else 0
    
    # Agrupar etapas por categoria
    etapas_por_categoria = {}
    for etapa in etapas_dict:
        categoria = etapa['categoria']
        if categoria not in etapas_por_categoria:
            etapas_por_categoria[categoria] = []
        etapas_por_categoria[categoria].append(etapa)
    
    # Buscar membros da equipe
    membros = db.execute('''
        SELECT id, nome, email
        FROM membro_equipe
        WHERE cliente_id = ? AND ativo = 1
        ORDER BY nome
    ''', (cliente_id,)).fetchall()
    
    return render_template(
        'seo_roadmap.html',
        cliente=cliente,
        etapas_por_categoria=etapas_por_categoria,
        progresso_geral=progresso_geral,
        membros=membros
    )

@app.route('/cliente/<int:cliente_id>/tarefas/atualizar', methods=['POST'])
@login_required
def atualizar_status_tarefa(cliente_id):
    try:
        db = get_db()
        data = request.get_json()
        tarefa_id = data.get('tarefa_id')
        status = data.get('status')
        
        if not tarefa_id or not status:
            return jsonify({'success': False, 'error': 'Dados incompletos'}), 400
            
        # Verificar se a tarefa pertence ao cliente
        tarefa = db.execute('''
            SELECT * FROM tarefa
            WHERE id = ? AND cliente_id = ?
        ''', (tarefa_id, cliente_id)).fetchone()
        
        if not tarefa:
            return jsonify({'success': False, 'error': 'Tarefa não encontrada'}), 404
            
        # Atualizar status da tarefa
        db.execute('''
            UPDATE tarefa
            SET status = ?,
                data_conclusao = CASE WHEN ? = 'concluida' THEN CURRENT_TIMESTAMP ELSE NULL END
            WHERE id = ?
        ''', (status, status, tarefa_id))
        
        db.commit()
        return jsonify({'success': True})
        
    except Exception as e:
        db.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/cliente/<int:cliente_id>/seo-roadmap/atualizar', methods=['POST'])
@login_required
def atualizar_progresso_seo(cliente_id):
    db = get_db()
    cliente = db.execute('''
        SELECT * FROM cliente 
        WHERE id = ? AND usuario_id = ?
    ''', (cliente_id, current_user.id)).fetchone()
    
    if not cliente:
        abort(404)
    
    data = request.get_json()
    etapa_id = data.get('etapa_id')
    status = data.get('status')
    observacoes = data.get('observacoes')
    
    try:
        # Verificar se já existe um progresso
        progresso = db.execute('''
            SELECT id FROM progresso_seo
            WHERE cliente_id = ? AND etapa_id = ?
        ''', (cliente_id, etapa_id)).fetchone()
        
        if progresso:
            # Atualizar progresso existente
            db.execute('''
                UPDATE progresso_seo
                SET status = ?,
                    data_conclusao = CASE WHEN ? = 'concluida' THEN CURRENT_TIMESTAMP ELSE NULL END,
                    observacoes = ?
                WHERE cliente_id = ? AND etapa_id = ?
            ''', (status, status, observacoes, cliente_id, etapa_id))
        else:
            # Criar novo progresso
            db.execute('''
                INSERT INTO progresso_seo (cliente_id, etapa_id, status, data_conclusao, observacoes)
                VALUES (?, ?, ?, 
                    CASE WHEN ? = 'concluida' THEN CURRENT_TIMESTAMP ELSE NULL END,
                    ?
                )
            ''', (cliente_id, etapa_id, status, status, observacoes))
        
        db.commit()
        return jsonify({'success': True})
        
    except Exception as e:
        db.rollback()
        return jsonify({'success': False, 'error': str(e)})

if __name__ == '__main__':
    app.run(debug=True)
